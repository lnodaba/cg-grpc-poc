import logging
import os

import oracledb

DATABASE_URL = os.getenv(
    "DATABASE_URL", "postgres://farm:farm@localhost:5432/acronyms"
)

# ORACLE_DB_URL = os.getenv(
#     "ORACLE_DB_URL", "oracle://oracle:oracle@localhost:1521?driver=Oracle+ODBC+Driver"
# )

# DATABASE_CONFIG = {
#     'connections': {
#         'default': ORACLE_DB_URL,
#     },
#     'apps': {
#         'models': {
#             'models': ['models.acronyms', 'models.acronyms_traindata', 'models.trainset', 'models.trainset_contents'],
#             'default_connection': 'default',
#         },
#     },
# }


DATABASE_CONFIG = {
    "connections": {
        "default": {
            "engine": "tortoise.backends.oracle",
            "credentials": {
                "user": "oracle",  # Your Oracle username
                "password": "oracle",  # Your Oracle password
                "host": "localhost",  # Host where Oracle DB is running
                "port": 1521,         # Default Oracle port
                "service_name": "FREEPDB1",  # Your PDB service name
                "driver": "cx_",  # ODBC driver for Oracle
            },
        }
    },
    "apps": {
        "models": {
            "models": ["models.acronyms", "models.acronyms_traindata", "models.trainset", "models.trainset_contents", "aerich.models"],
            "default_connection": "default",
        }
    },
}
