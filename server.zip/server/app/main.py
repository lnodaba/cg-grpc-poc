import asyncio
import os

from aerich import Command
from tortoise import Tortoise
from grpc import aio

from services.proto import acronyms_pb2_grpc
from config import DATABASE_CONFIG

from structlog import get_logger

from services.trainset_service import TrainsetService
from services.acronyms_service import AcronymService
from services.acronyms_traindata_service import AcronymTrainDataService
from services.trainset_contetns_service import TrainsetContentService
import logging
logger = get_logger()
logging.basicConfig(level=logging.DEBUG)


async def main():
    server = None  # Initialize server here to ensure it's in scope
    # try:
    # os.environ['PATH'] = r"C:\Users\Olah-Ilkei Kund\Documents\instantclient_23_5;" + os.environ['PATH']
    # logger.info("Starting server...")
    # oracledb.init_oracle_client()  # Ensure this is called first

    await Tortoise.init(config=DATABASE_CONFIG)
    logger.info("Tortoise ORM initialized")

    connection = Tortoise.get_connection('default')
    await connection.create_connection(with_db=True)
    
    # logger.info("Database connection established")
    
    # command = Command(tortoise_config=DATABASE_CONFIG, app='models')
    # await command.init()
    # await command.upgrade()
    # logger.info("Database upgraded")

    # await Tortoise.generate_schemas(safe=True)
    logger.info("Database and schemas generated")

    # server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    server = aio.server()  # Use aio for async
    acronyms_pb2_grpc.add_AcronymTrainDataServiceServicer_to_server(
        AcronymTrainDataService(), server
    )

    acronyms_pb2_grpc.add_AcronymServiceServicer_to_server(
        AcronymService(), server
    )

    acronyms_pb2_grpc.add_TrainsetContentServiceServicer_to_server(
        TrainsetContentService(), server
    )

    acronyms_pb2_grpc.add_TrainsetServiceServicer_to_server(
        TrainsetService(), server
    )

    server.add_insecure_port("[::]:50051")
    logger.info("Server started on port 50051")
    await server.start()
    await server.wait_for_termination()
    # except Exception as e:
    #     logger.error(f"Error: {e}")
    #     # traceback.print_exc()
    #     logger.error("Server stopped")
    # finally:
    #     # Close all database connections
    #     await Tortoise.close_connections()
    #     logger.info("Database connections closed")
    #     logger.info("Server stopped")

if __name__ == "__main__":
    asyncio.run(main())
