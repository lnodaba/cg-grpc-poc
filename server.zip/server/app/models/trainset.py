from models.base_model import BaseModel
from tortoise import fields
from tortoise.exceptions import DoesNotExist


class Trainset(BaseModel):

    class Meta:
        table = "TRAINSET"

    id = fields.IntField(pk=True, db_column='ID')
    last_run = fields.DatetimeField(null=True, db_column='LAST_RUN')
    base_model_inst_id = fields.IntField(null=True, db_column='BASE_MODEL_INST_ID')
    new_model_inst_id = fields.IntField(null=True, db_column='NEW_MODEL_INST_ID')
    description = fields.CharField(max_length=1000, null=True, db_column='DESCRIPTION')
    create_dt = fields.DatetimeField(auto_now_add=True, db_column='CREATE_DT')
