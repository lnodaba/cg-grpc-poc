from tortoise.models import Model
from tortoise.exceptions import DoesNotExist


class BaseModel(Model):

    class Meta:
        abstract = True

    def __str__(self):
        return str(self.__dict__)
