from .base_model import BaseModel
from tortoise import fields


class AcronymTrainData(BaseModel):

    class Meta:
        table = "ACRONYMS_TRAINDATA"

    id = fields.IntField(pk=True, db_column='ID')
    acronym_id = fields.IntField(null=True, db_column='ACRONYM_ID')
    provided_by = fields.CharField(max_length=20, null=True, db_column='PROVIDED_BY')
    generated_bytrainset_id = fields.IntField(null=True, db_column='GENERATED_BYTRAINSET_ID')
    text_en = fields.TextField(max_length=4000, null=True, db_column='TEXT_EN')
    text_fr = fields.CharField(max_length=4000, null=True, db_column='TEXT_FR')
    reason = fields.CharField(max_length=500, null=True, db_column='REASON')
    create_dt = fields.DatetimeField(auto_now_add=True, db_column='CREATE_DT')
