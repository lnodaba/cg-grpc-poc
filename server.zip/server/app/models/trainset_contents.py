from models.base_model import BaseModel
from tortoise import fields


class TrainsetContent(BaseModel):

    class Meta:
        table = "TRAINSET_CONTENTS"

    id = fields.IntField(pk=True, db_column='ID')
    trainset_id = fields.IntField(null=True, db_column='TRAINSET_ID')
    acronym_id = fields.IntField(null=True, db_column='ACRONYM_ID')
    traindata_id = fields.IntField(null=True, db_column='TRAINDATA_ID')
    role = fields.CharField(max_length=20, null=True, db_column='ROLE')
