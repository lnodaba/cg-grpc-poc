import asyncio
import logging
import os
from tortoise import Tortoise

# Enable detailed logging
logging.basicConfig(level=logging.DEBUG)

DATABASE_CONFIG = {
    "connections": {
        "default": {
            "engine": "tortoise.backends.oracle",  # Oracle DB engine
            "credentials": {
                "user": "oracle",
                "password": "oracle",
                "host": "localhost",
                "port": 1521,
                "service_name": "FREEPDB1",  # Ensure this is correct
                "driver": "oracledb",  # Check if oracledb is installed, or use cx_Oracle
            },
        }
    },
    "apps": {
        "models": {
            "models": ["models.acronyms"],  # Use the correct path to your model
            "default_connection": "default",
        }
    },
}

async def test_connection():
    # Initialize the connection with Tortoise ORM
    await Tortoise.init(config=DATABASE_CONFIG)
    print("Connection established successfully.")
    
    # You can also verify by executing a simple query to test DB connection
    await Tortoise.get_connection("default").execute_query("SELECT 1 FROM dual")
    print("Simple query executed successfully.")
    
        
        
import asyncio

async def cx_test():
    import cx_Oracle
    os.environ['PATH'] = r"C:\Users\Olah-Ilkei Kund\Documents\instantclient_23_5;" + os.environ['PATH']

    dsn = cx_Oracle.makedsn("localhost", 1521, service_name="FREEPDB1")
    try:
        connection = cx_Oracle.connect(user="oracle", password="oracle", dsn=dsn)
        print("Connected to Oracle DB successfully!")
        connection.close()
    except cx_Oracle.DatabaseError as e:
        print(f"Failed to connect: {e}")



import asyncio
import oracledb

async def test_oracledb():
    # Initialize Oracle client with the path to the Instant Client
    # lib_dir=r"C:\Users\Olah-Ilkei Kund\Documents\instantclient_23_5"
    # oracledb.init_oracle_client()
    os.environ['PATH'] = r"C:\Users\Olah-Ilkei Kund\Documents\instantclient_23_5;" + os.environ['PATH']


    oracledb.init_oracle_client()  # No lib_dir needed now

    try:
        # Establish the connection to the Oracle database
        connection = oracledb.connect(user="oracle", password="oracle", dsn="localhost:1521/FREEPDB1")
        print("Connected to Oracle DB successfully!")
        
        # Create a cursor object to execute SQL queries
        cursor = connection.cursor()
        
        # Execute a query to list tables in the user's schema
        cursor.execute("SELECT table_name FROM user_tables")
        
        # Fetch all results
        tables = cursor.fetchall()
        
        print("Tables in the database:")
        for table in tables:
            print(table[0])  # table is a tuple, so get the first element
            
    except oracledb.DatabaseError as e:
        print(f"Failed to connect or retrieve tables: {e}")
    finally:
        # Ensure the cursor and connection are closed properly
        cursor.close()
        connection.close()



if __name__ == '__main__':
    # asyncio.run(test_connection())
    asyncio.run(test_connection())
